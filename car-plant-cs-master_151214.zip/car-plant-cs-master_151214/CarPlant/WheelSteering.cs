﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CarPlant
{
    public interface ISteering
    {
        void TurnLeft(int degrees);
        void TurnRight(int degrees);
    }

    public class WheelSteering : ISteering
    {
        private List<Wheel> _wheels;

        public WheelSteering(List<Wheel> wheels)
        {
            _wheels = wheels;
        }

        public void TurnLeft(int degrees)
        {
            _wheels.ForEach(x => x.turnLeft(degrees));
        }

        public void TurnRight(int degrees)
        {
            _wheels.ForEach(x => x.turnRight(degrees));
        }
    }
}
