using System;

namespace CarPlant
{
	public class Car
	{
        private ISteering _steering;
        private IDrive _drive;
        private string _name;

        public Car(string name, ISteering steering, IDrive drive)
        {
            _name = name;
            _steering = steering;
            _drive = drive;
        }

        public string Name()
        {
            return _name;
        }

        public void Accelerate(int kmsPerHour)
        {
            _drive.Accelerate(kmsPerHour);
        }

		public void TurnLeft(int degrees)
		{
            _steering.TurnLeft(degrees);
		}

		public void TurnRight(int degrees)
		{
            _steering.TurnRight(degrees);
		}
	}
}