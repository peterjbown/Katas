﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CarPlant
{
    public interface IDrive
    {
        void Accelerate(int kmsPerHour);
    }

    public class WheelDrive : IDrive
    {
        private List<Wheel> _wheels;

        public WheelDrive(List<Wheel> wheels)
        {
            _wheels = wheels;
        }

        public void Accelerate(int kph)
        {
            _wheels.ForEach(x => x.rotate(kph));
        }
    }
}
