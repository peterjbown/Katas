using System.Collections.Generic;
using System.Linq;

namespace CarPlant {
	public class CarPlant
	{
		public static string LOG;

		public static Car makeToyotaCorolla()
		{
            List<Wheel> frontWheels = CreateFrontWheelsList();

            var steering = new WheelSteering(frontWheels);
            var drive = new WheelDrive(frontWheels);

            return new Car("Toyota Corolla", steering, drive);
		}

		public static Car makeToyotaCorollaSports()
		{
            var steering = new WheelSteering(CreateFrontWheelsList());
            var drive = new WheelDrive(CreateRearWheelsList());

            return new Car("Toyota Corolla sports", steering, drive);
		}

		public static Car makeMitsubishiTriton()
		{
            var steering = new WheelSteering(CreateFrontWheelsList());
            var drive = new WheelDrive(CreateFourWheelsList());

            return new Car("Mitsubishi Triton", steering, drive);
		}

		public static Car makeSandBuggy()
		{
            List<Wheel> fourWheels = CreateFourWheelsList();

            var steering = new WheelSteering(fourWheels);
            var drive = new WheelDrive(fourWheels);

            return new Car("Sand Buggy", steering, drive);
		}

		public static Car makeSandBuggyLite()
		{
            var steering = new WheelSteering(CreateFourWheelsList());
            var drive = new WheelDrive(CreateRearWheelsList());

            return new Car("Sand Buggy Lite", steering, drive);
		}

        public static Car makeRobinRelliant()
        {
            var centre = new Wheel("centre");

            List<Wheel> frontWheels = new List<Wheel>()
            { 
                centre
            };

            var steering = new WheelSteering(frontWheels);
            var drive = new WheelDrive(CreateRearWheelsList());

            return new Car("Robin Relliant", steering, drive);
        }

        private static List<Wheel> CreateFrontWheelsList()
        {
            var frontLeft = new Wheel("front left");
            var frontRight = new Wheel("front right");

            List<Wheel> frontWheels = new List<Wheel>()
            { 
                frontLeft,
                frontRight
            };

            return frontWheels;
        }

        private static List<Wheel> CreateRearWheelsList()
        {
            var rearLeft = new Wheel("rear left");
            var rearRight = new Wheel("rear right");

            List<Wheel> rearWheels = new List<Wheel>()
            { 
                rearLeft,
                rearRight
            };

            return rearWheels;
        }

        private static List<Wheel> CreateFourWheelsList()
        {
            var frontLeft = new Wheel("front left");
            var frontRight = new Wheel("front right");
            var rearLeft = new Wheel("rear left");
            var rearRight = new Wheel("rear right");

            List<Wheel> fourWheels = new List<Wheel>()
            { 
                frontLeft,
                frontRight,
                rearLeft,
                rearRight
            };

            return fourWheels;
        }
    }
}