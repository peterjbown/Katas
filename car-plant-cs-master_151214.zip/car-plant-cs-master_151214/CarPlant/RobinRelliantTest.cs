﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CarPlant
{
    [TestClass]
    public class RobinRelliantTest
    {
        private Car car;

        [TestInitialize]
        public void Init()
        {
            CarPlant.LOG = "";
            car = CarPlant.makeRobinRelliant();
        }

        [TestMethod]
        public void HasTheCorrectName()
        {
            Assert.AreEqual("Robin Relliant", car.Name());
        }

        [TestMethod]
        public void TurningLeftOnlyTurnsTheCentreWheel()
        {
            int degrees = TestHelpers.randomDegrees();
            car.TurnLeft(degrees);
            Assert.AreEqual("centre turning left " + degrees + " degrees\n", CarPlant.LOG);
        }

        [TestMethod]
        public void TurningRightOnlyTurnsTheCentreWheel()
        {
            int degrees = TestHelpers.randomDegrees();
            car.TurnRight(degrees);
            Assert.AreEqual("centre turning right " + degrees + " degrees\n", CarPlant.LOG);
        }

        [TestMethod]
        public void AcceleratingTurnsRearWheels()
        {
            int speed = TestHelpers.randomSpeed();
            car.Accelerate(speed);
            Assert.AreEqual("rear left accelerating " + speed + " kph\n"
                         + "rear right accelerating " + speed + " kph\n", CarPlant.LOG);
        }
    }
}
